import java.io.PrintStream
import java.net.ServerSocket
import java.sql.Connection
import java.sql.DriverManager
import java.sql.SQLException
import java.util.concurrent.ConcurrentHashMap

class ChatServer(private val port: Int) {
    private val serverSocket = ServerSocket(port)
    private val clients = ConcurrentHashMap<String, ClientHandler>()
    private val dbConnection: Connection

    init {
        try {
            Class.forName("org.sqlite.JDBC") // Регистрируем драйвер
        } catch (e: ClassNotFoundException) {
            println("SQLite driver not found! Please add sqlite-jdbc.jar to your project")
            System.exit(1)
        }

        // Инициализация базы данных
        dbConnection = DriverManager.getConnection("jdbc:sqlite:chat.db")
        initializeDatabase()
    }

    private fun initializeDatabase() {
        val stmt = dbConnection.createStatement()
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        """)
        stmt.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sender TEXT NOT NULL,
                receiver TEXT NOT NULL,
                message TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
    }

    fun start() {
        println("Сервер запущен на порту $port")
//        while (true) {
//            val clientSocket = serverSocket.accept()
//            val handler = ClientHandler(clientSocket, this)
//            Thread(handler).start()
//        }
        println("Ожидание подключений...")

        while (true) {
            try {
                val clientSocket = serverSocket.accept()
                println("Новое подключение от: ${clientSocket.inetAddress.hostAddress}")
                val handler = ClientHandler(clientSocket, this)
                Thread(handler).start()
                println("Обработчик запущен в отдельном потоке")
            } catch (e: Exception) {
                println("Ошибка при принятии подключения: ${e.message}")
            }
        }
    }

    fun registerUser(username: String, password: String): Boolean {
        return try {
            val stmt = dbConnection.prepareStatement("INSERT INTO users (username, password) VALUES (?, ?)")
            stmt.setString(1, username)
            stmt.setString(2, password)
            stmt.executeUpdate() > 0
        } catch (e: SQLException) {
            false
        }
    }

    fun authenticateUser(username: String, password: String): Boolean {
        val stmt = dbConnection.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?")
        stmt.setString(1, username)
        stmt.setString(2, password)
        return stmt.executeQuery().next()
    }

    fun addClient(username: String, handler: ClientHandler) {
        clients[username] = handler
        broadcast("$username присоединился к чату")
    }

    fun removeClient(username: String) {
        clients.remove(username)
        broadcast("$username покинул чат")
    }

    fun sendPrivateMessage(sender: String, receiver: String, message: String) {
        val stmt = dbConnection.prepareStatement("INSERT INTO messages (sender, receiver, message) VALUES (?, ?, ?)")
        stmt.setString(1, sender)
        stmt.setString(2, receiver)
        stmt.setString(3, message)
        stmt.executeUpdate()

        clients[receiver]?.sendMessage("[$sender -> вам]: $message")
    }

    fun broadcast(message: String, excludeUser: String? = null) {
        clients.forEach { (username, handler) ->
            if (username != excludeUser) {
                handler.sendMessage(message)
            }
        }
    }

    fun getOnlineUsers(): List<String> = clients.keys.toList()

    fun getMessageHistory(user1: String, user2: String): List<String> {
        val messages = mutableListOf<String>()
        val stmt = dbConnection.prepareStatement("""
            SELECT sender, receiver, message FROM messages 
            WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?)
            ORDER BY timestamp
        """)
        stmt.setString(1, user1)
        stmt.setString(2, user2)
        stmt.setString(3, user2)
        stmt.setString(4, user1)
        val rs = stmt.executeQuery()

        while (rs.next()) {
            messages.add("[${rs.getString("sender")} -> ${rs.getString("receiver")}]: ${rs.getString("message")}")
        }
        return messages
    }
}

fun main() {
    System.setOut(PrintStream(System.out, true, "UTF-8"))
    val server = ChatServer(8888)
    server.start()
}