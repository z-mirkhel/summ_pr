import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.Socket

class ClientHandler(
    private val socket: Socket,
    private val server: ChatServer
) : Runnable {
    private val reader: BufferedReader
    private val writer: PrintWriter
    private var username: String? = null

    init {
        reader = BufferedReader(InputStreamReader(socket.getInputStream()))
        writer = PrintWriter(socket.getOutputStream(), true)
    }

    override fun run() {
        try {
            while (true) {
                val message = reader.readLine() ?: break
                when {
                    message.startsWith("LOGIN:") -> {
                        val parts = message.split(":")
                        if (parts.size == 3) {
                            val user = parts[1]
                            val pass = parts[2]
                            if (server.authenticateUser(user, pass)) {
                                username = user
                                server.addClient(user, this)
                                writer.println("LOGIN_SUCCESS")
                            } else {
                                writer.println("LOGIN_FAILED")
                            }
                        }
                    }
                    message.startsWith("REGISTER:") -> {
                        val parts = message.split(":")
                        if (parts.size == 3) {
                            val user = parts[1]
                            val pass = parts[2]
                            if (server.registerUser(user, pass)) {
                                writer.println("REGISTER_SUCCESS")
                            } else {
                                writer.println("REGISTER_FAILED")
                            }
                        }
                    }
                    message.startsWith("BROADCAST:") -> {
                        if (username != null) {
                            val msg = message.substringAfter("BROADCAST:")
                            server.broadcast("[$username]: $msg")
                        }
                    }
                    message.startsWith("PRIVATE:") -> {
                        if (username != null) {
                            val parts = message.split(":", limit = 3)
                            if (parts.size == 3) {
                                val receiver = parts[1]
                                val msg = parts[2]
                                server.sendPrivateMessage(username!!, receiver, msg)
                                writer.println("[вы -> $receiver]: $msg")
                            }
                        }
                    }
                    message == "GET_USERS" -> {
                        val users = server.getOnlineUsers().joinToString(", ")
                        writer.println("Онлайн пользователи: $users")
                    }
                    message.startsWith("GET_HISTORY:") -> {
                        if (username != null) {
                            val otherUser = message.substringAfter("GET_HISTORY:")
                            val history = server.getMessageHistory(username!!, otherUser)
                            writer.println("История сообщений с $otherUser:")
                            history.forEach { writer.println(it) }
                            writer.println("Конец истории")
                        }
                    }
                    message == "EXIT" -> {
                        if (username != null) {
                            server.removeClient(username!!)
                        }
                        break
                    }
                }
            }
        } catch (e: Exception) {
            println("Ошибка обработки клиента: ${e.message}")
        } finally {
            socket.close()
            username?.let { server.removeClient(it) }
        }
    }

    fun sendMessage(message: String) {
        writer.println(message)
    }
}