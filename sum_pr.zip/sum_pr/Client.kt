import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintStream
import java.io.PrintWriter
import java.net.Socket
import java.util.*

class ChatClient(private val serverAddress: String, private val port: Int) {
    private var socket: Socket? = null
    private var reader: BufferedReader? = null
    private var writer: PrintWriter? = null
    private var username: String? = null
    private val scanner = Scanner(System.`in`)

    fun start() {
        try {
            socket = Socket(serverAddress, port)
            reader = BufferedReader(InputStreamReader(socket!!.getInputStream()))
            writer = PrintWriter(socket!!.getOutputStream(), true)

            // Поток для чтения сообщений от сервера
            Thread {
                try {
                    while (true) {
                        val message = reader?.readLine() ?: break
                        println(message)
                    }
                } catch (e: Exception) {
                    println("Соединение с сервером потеряно")
                }
            }.start()

            // Авторизация/регистрация
            while (username == null) {
                println("Введите команду (login/register):")
                val command = scanner.nextLine()
                println("Введите имя пользователя:")
                val user = scanner.nextLine()
                println("Введите пароль:")
                val pass = scanner.nextLine()

                when (command) {
                    "login" -> {
                        writer?.println("LOGIN:$user:$pass")
                        val response = reader?.readLine()
                        if (response == "LOGIN_SUCCESS") {
                            username = user
                            println("Авторизация успешна")
                        } else {
                            println("Ошибка авторизации")
                        }
                    }
                    "register" -> {
                        writer?.println("REGISTER:$user:$pass")
                        val response = reader?.readLine()
                        if (response == "REGISTER_SUCCESS") {
                            println("Регистрация успешна")
                        } else {
                            println("Ошибка регистрации (возможно, имя уже занято)")
                        }
                    }
                    else -> println("Неизвестная команда")
                }
            }

            // Основной цикл ввода команд
            while (true) {
                print("> ")
                val input = scanner.nextLine()
                when {
                    input.startsWith("/pm") -> {
                        val parts = input.split(" ", limit = 3)
                        if (parts.size == 3) {
                            writer?.println("PRIVATE:${parts[1]}:${parts[2]}")
                        } else {
                            println("Использование: /pm <получатель> <сообщение>")
                        }
                    }
                    input == "/users" -> {
                        writer?.println("GET_USERS")
                    }
                    input.startsWith("/history") -> {
                        val parts = input.split(" ", limit = 2)
                        if (parts.size == 2) {
                            writer?.println("GET_HISTORY:${parts[1]}")
                        } else {
                            println("Использование: /history <пользователь>")
                        }
                    }
                    input == "/exit" -> {
                        writer?.println("EXIT")
                        break
                    }
                    else -> {
                        writer?.println("BROADCAST:$input")
                    }
                }
            }
        } catch (e: Exception) {
            println("Ошибка: ${e.message}")
        } finally {
            socket?.close()
        }
    }
}

fun main() {
    System.setOut(PrintStream(System.out, true, "UTF-8"))

    println("Введите адрес сервера (по умолчанию localhost):")
    val address = readLine()?.ifBlank { "localhost" } ?: "localhost"
    println("Введите порт (по умолчанию 9999):")
    val port = readLine()?.toIntOrNull() ?: 8888

    val client = ChatClient(address, port)
    client.start()
}
